/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package graphicsexercise;

import java.awt.*;
import javax.swing.*;

public class GraphicsExercise extends JPanel {

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 24));
        g.drawString("night", 10, 20);
        
        g.setColor(Color.blue); 
        g.drawRect(1, 30, 600, 200); 
        g.fillRect(1, 30, 600, 200); 
        g.setColor(Color.green); 
        g.drawRect(1, 228, 600, 200);
        g.fillRect(1, 228, 600, 200);  
        
        g.setColor(Color.black);
        g.drawRect(400, 100, 20, 200);
        g.fillRect(400, 100, 20, 200);  
        g.setColor(Color.black);
        g.drawRect(350, 100, 50, 20);
        g.fillRect(350, 100, 50, 20); 
        
          
        g.setColor(Color.yellow);
        g.drawRect(360, 120, 30, 10);
        g.fillRect(360, 120, 30, 10); 


        g.setColor(Color.yellow); 
        int[] xPoints = {75, 87, 129, 93, 103, 75, 47, 57, 21, 63}; 
        int[] yPoints = {34, 70, 70, 88, 130, 106, 130, 88, 70, 70}; 
        int nPoints = 10;
        g.fillPolygon(xPoints, yPoints, nPoints);
        
        g.setColor(Color.YELLOW);
        int[] xPoints2 = {175, 185, 200, 190, 195, 175, 155, 160, 150, 165}; 
        int[] yPoints2 = {70, 90, 90, 100, 130, 115, 130, 100, 90, 90}; 
        int nPoints2 = 10; 
        g.fillPolygon(xPoints2, yPoints2, nPoints2);

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Graphics Exercise");
        GraphicsExercise panel = new GraphicsExercise();

        frame.add(panel);
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
